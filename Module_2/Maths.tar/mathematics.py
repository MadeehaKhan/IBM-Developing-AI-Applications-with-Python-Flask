def summation(a, b):
    '''
    Computes and returns the sum of a and b
    '''
    return a + b

def subtraction(a, b):
    '''
    Computes and returns the difference of a and b
    '''
    return a - b

def multiplication(a,b):
    '''
    Computes and returns the product of a and b
    '''
    return a * b